$(document).ready(function(){
  alert("sdfsdf");
})
;
